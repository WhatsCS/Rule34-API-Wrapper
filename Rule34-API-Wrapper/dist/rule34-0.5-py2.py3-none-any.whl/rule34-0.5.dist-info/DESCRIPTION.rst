An API wrapper for rule34.xxx


